#include "mbed.h"

#define PULSE_WIDTH 100
#define ONE_DELAY   1000
#define ZERO_DELAY  4000
#define THRESHOLD   2000


Serial pc(USBTX, USBRX);
DigitalOut  my_led(LED1);
InterruptIn signal_in(D15);
Timeout reset;
Timer t;

int i;
int j;
int k;
int width;
char buff[1024];
char print_buff[1024];
char nextChar[9];

/*void reset_buffer() {
    my_led  = 0;
    char c = 0;
    k = 0;
    buff[i] = '\n';
    buff[i+1] = '\r';
    buff[i+2] = '\0';
    i       = 0;
    pc.printf(buff);
    pc.printf("%d\n\r", width);
}*/

void reset_buffer() {
    my_led  = 0;
    unsigned char c = 0;
    k = 0;
    for (int y = 0; y < i; y = y + 8){
        c = 0;
        for(int x = 0; x < 8; x++) {
            c = c << 1;
            if (buff[7+y-x] & 0x01 == 1) c += 0x01;
        }
        pc.printf("%c",c);
    }
    pc.printf("\n\r");
    buff[i] = '\n';
    buff[i+1] = '\r';
    buff[i+2] = '\0';
    i       = 0;
    nextChar[8] = '\0';
    pc.printf(buff);
    pc.printf("\n\r");
    //pc.printf(nextChar);
}

void signal_up() {
    my_led  = 1;
    width   = t.read_us();
    t.stop();
    t.reset();
    if(width > THRESHOLD) {
        buff[i] = '0';
    } else {
        buff[i] = '1';
    } 
    i++;
    reset.attach_us(&reset_buffer, 2*PULSE_WIDTH);
    return;
}

void signal_down() {
    reset.detach();
    t.start();
    my_led = 0;
    return;
}

int main()
{
    i = 0;
    j = 0;
    signal_in.rise(&signal_up);
    signal_in.fall(&signal_down);
    while (1) {
        wait(1);
    }
}
