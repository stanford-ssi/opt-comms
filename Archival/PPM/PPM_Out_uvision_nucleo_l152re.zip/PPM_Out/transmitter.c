#include "transmitter.h"

#define PULSE_WIDTH 1000
#define ONE_DELAY   10000
#define ZERO_DELAY  40000


/*
void transmit_bit(char c) {
    int i;
    for (i = 0; i < 8; i++) {
        myled = 1;
        wait_us(PULSE_WIDTH);
        myled = 0;
        if (c & 0x1) {
            wait_us(ONE_DELAY);
        } else {
            wait_us(ZERO_DELAY);
        }
        c >>= 1;
    }
}

void transmit(char * data, unsigned int size) {
    int i;
    for (i = 0; i < size; i++) {
        transmit_bit(data[i]);
    }
}*/