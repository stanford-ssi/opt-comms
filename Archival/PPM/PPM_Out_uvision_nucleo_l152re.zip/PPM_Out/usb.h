#ifndef usb_h
#define usb_h

char usb_read();
void usb_write(char * text);

#endif