#ifndef transmitter_h
#define transmitter_h

void transmit_bit(char c);
void transmit(char * data, unsigned int size);

#endif