#include "mbed.h"
#include "usb.h"

Serial pc(SERIAL_TX, SERIAL_RX);

void usb_write(char * text) {
    pc.printf(text);
}

char usb_read() {
    return pc.getc();
}