#include "mbed.h"
#include "usb.h"

//------------------------------------
// Hyperterminal configuration
// 9600 bauds, 8-bit data, no parity
//------------------------------------


#define PULSE_WIDTH 100
#define ONE_DELAY   1000
#define ZERO_DELAY  4000

DigitalOut myled(LED1);
DigitalOut outpin(D15);
char buff[1024];

void transmit_bit(char c) {
    int i;
    for (i = 0; i < 8; i++) {
        myled = 1;
        outpin = 1;
        wait_us(PULSE_WIDTH);
        myled = 0;
        outpin = 0;
        if (c & 0x1) {
            wait_us(ONE_DELAY);
        } else {
            wait_us(ZERO_DELAY);
        }
        c >>= 1;
    }
}

void transmit(char * data, unsigned int size) {
    int i;
    for (i = 0; i < size; i++) {
        transmit_bit(data[i]);
    }
}

int getData(char * data) {
    int numChar = 0;
    while (1) {
        buff[numChar] = usb_read();
        if (buff[numChar] == '\n' || buff[numChar] == '\r') break;
        numChar++;
    }
    return numChar;
}
 
int main() {
  myled = 1;
  outpin = 1;
  usb_write("Hello World !\n\r");
  while(1) {
      myled = 1;
      outpin = 1;
      wait(1);
      transmit("Hello World!", 12);
      
      myled = 1;
      outpin = 1;
      wait(1);
      //usb_write(str);
      transmit("I am a PPM Signal!", 18);
  }
}

